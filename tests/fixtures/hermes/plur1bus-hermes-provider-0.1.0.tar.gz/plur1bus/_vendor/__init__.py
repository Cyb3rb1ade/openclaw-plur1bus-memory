"""Vendored copies of the provider's dependencies (HM2-R4); written by scripts/build-hermes-provider.mjs."""
